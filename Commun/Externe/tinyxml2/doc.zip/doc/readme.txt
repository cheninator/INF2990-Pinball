La documentation est disponible en ligne à l'adresse suivante :
http://www.grinninglizard.com/tinyxml2docs/index.html