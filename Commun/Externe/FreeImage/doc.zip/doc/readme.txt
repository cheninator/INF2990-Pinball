La librairie FreeImage peut �tre trouv�e �:

http://freeimage.sourceforge.net/

Le fichier d'inclusion, la librairie .lib pour l'�diteur de lien et la librairie dynamique (de la distribution binaire de la version 3.9.1) ont �t� mis disponibles pour les autres projets.
