var structInterfaceGraphique_1_1FonctionsNatives_1_1Message =
[
    [ "hWnd", "d6/d9b/structInterfaceGraphique_1_1FonctionsNatives_1_1Message.html#aa25d996ad709246eecada71a0f375b21", null ],
    [ "lParam", "d6/d9b/structInterfaceGraphique_1_1FonctionsNatives_1_1Message.html#afc019b6c13559ba2a12a64e24eba9baf", null ],
    [ "Msg", "d6/d9b/structInterfaceGraphique_1_1FonctionsNatives_1_1Message.html#a1b1dfd72e58f292bbd24d6dc7a0b0f61", null ],
    [ "Point", "d6/d9b/structInterfaceGraphique_1_1FonctionsNatives_1_1Message.html#a9dc93f6c7f6db4f91386aef27b0a77ad", null ],
    [ "Time", "d6/d9b/structInterfaceGraphique_1_1FonctionsNatives_1_1Message.html#ae0ab10151482b01c9c5fe1cb4e8a2306", null ],
    [ "wParam", "d6/d9b/structInterfaceGraphique_1_1FonctionsNatives_1_1Message.html#aa04705defc08a7fea09f90b1cd069e20", null ]
];