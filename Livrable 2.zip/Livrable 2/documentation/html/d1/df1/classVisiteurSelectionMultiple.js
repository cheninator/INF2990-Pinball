var classVisiteurSelectionMultiple =
[
    [ "VisiteurSelectionMultiple", "d1/df1/classVisiteurSelectionMultiple.html#ac4db71a717e4fde35fa0972f0bd745a7", null ],
    [ "~VisiteurSelectionMultiple", "d1/df1/classVisiteurSelectionMultiple.html#a2bfc189af731260f08919e1bc42edb6f", null ],
    [ "VisiteurSelectionMultiple", "d1/df1/classVisiteurSelectionMultiple.html#a130b2da1a17e3f1b6b6dd4dca460b632", null ],
    [ "obtenirNbObjetsSelectionne", "d1/df1/classVisiteurSelectionMultiple.html#a29be242014ed77e7a72ef4fe51615fb4", null ],
    [ "traiter", "d1/df1/classVisiteurSelectionMultiple.html#ad557f683ffaba61faa3f9022fbe39f90", null ],
    [ "traiter", "d1/df1/classVisiteurSelectionMultiple.html#a932d9fa6b7a12032562d610176cfd419", null ],
    [ "traiter", "d1/df1/classVisiteurSelectionMultiple.html#a1f2938b040d83d782fc0994ea3683e7c", null ],
    [ "nbObjetsSelectionne_", "d1/df1/classVisiteurSelectionMultiple.html#a404343a656555e316792034c360c8749", null ],
    [ "selectionBasGauche_", "d1/df1/classVisiteurSelectionMultiple.html#ac13a064cc4866ccfb126102d1f88927f", null ],
    [ "selectionHautDroit_", "d1/df1/classVisiteurSelectionMultiple.html#a65315ef40dfb9479e6235a674b833a63", null ]
];