var classInterfaceGraphique_1_1Properties_1_1Settings =
[
    [ "defaultInstance", "d4/da9/classInterfaceGraphique_1_1Properties_1_1Settings.html#aa03b1fe9240f07012f62ccc0e9166c21", null ],
    [ "Default", "d4/da9/classInterfaceGraphique_1_1Properties_1_1Settings.html#ab643139c8f5ba32ffc060b2a22d5d01f", null ]
];