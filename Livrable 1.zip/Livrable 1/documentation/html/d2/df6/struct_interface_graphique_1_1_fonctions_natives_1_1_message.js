var struct_interface_graphique_1_1_fonctions_natives_1_1_message =
[
    [ "hWnd", "d2/df6/struct_interface_graphique_1_1_fonctions_natives_1_1_message.html#aa25d996ad709246eecada71a0f375b21", null ],
    [ "lParam", "d2/df6/struct_interface_graphique_1_1_fonctions_natives_1_1_message.html#afc019b6c13559ba2a12a64e24eba9baf", null ],
    [ "Msg", "d2/df6/struct_interface_graphique_1_1_fonctions_natives_1_1_message.html#a1b1dfd72e58f292bbd24d6dc7a0b0f61", null ],
    [ "Point", "d2/df6/struct_interface_graphique_1_1_fonctions_natives_1_1_message.html#a9dc93f6c7f6db4f91386aef27b0a77ad", null ],
    [ "Time", "d2/df6/struct_interface_graphique_1_1_fonctions_natives_1_1_message.html#ae0ab10151482b01c9c5fe1cb4e8a2306", null ],
    [ "wParam", "d2/df6/struct_interface_graphique_1_1_fonctions_natives_1_1_message.html#aa04705defc08a7fea09f90b1cd069e20", null ]
];