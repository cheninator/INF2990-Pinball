var class_interface_graphique_1_1_proprietes =
[
    [ "Proprietes", "d7/d11/class_interface_graphique_1_1_proprietes.html#a21b29046c0449a57829c2dedfab950cd", null ],
    [ "Dispose", "d7/d11/class_interface_graphique_1_1_proprietes.html#a8a8dc4e8340e98beac626348989bb1d5", null ],
    [ "getProps", "d7/d11/class_interface_graphique_1_1_proprietes.html#a631a4fe28b7784deb13ac0295cb89d9d", null ],
    [ "mesProp", "d7/d11/class_interface_graphique_1_1_proprietes.html#ac4856009edf043248883a2a908300035", null ]
];