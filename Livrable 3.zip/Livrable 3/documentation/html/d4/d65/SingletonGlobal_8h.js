var SingletonGlobal_8h =
[
    [ "SingletonGlobal", "d3/df4/classSingletonGlobal.html", "d3/df4/classSingletonGlobal" ],
    [ "SoundControl", "d4/d65/SingletonGlobal_8h.html#adc6e69ad757c126d8d901858002db1d0", null ]
];