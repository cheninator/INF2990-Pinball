var ControleurTexte_8cpp =
[
    [ "MARGE_X", "d4/d2d/ControleurTexte_8cpp.html#aa4402f44f952e98a7481dfb217323e4f", null ],
    [ "MARGE_Y", "d4/d2d/ControleurTexte_8cpp.html#a96d03e50649c1e9c164f7283b29dd946", null ]
];