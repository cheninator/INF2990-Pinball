var classMemento =
[
    [ "Memento", "d2/dfd/classMemento.html#ad4f6b7c8de3d43fc0fca2e0a6d2e3a8a", null ],
    [ "~Memento", "d2/dfd/classMemento.html#af680b5488989567d0f03d655c4232924", null ],
    [ "obtenirSauvegarde", "d2/dfd/classMemento.html#a8f27eec558dfb7d18d2940074468c3d3", null ],
    [ "sauvegarder", "d2/dfd/classMemento.html#a839b7e8c03215e25b3a66e36078ea9e1", null ],
    [ "sauvegarde", "d2/dfd/classMemento.html#a8236cd118199e153d96dd85f54b85372", null ]
];