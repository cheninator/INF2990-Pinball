var namespaceInterfaceGraphique_1_1Properties =
[
    [ "Resources", "d7/d9c/classInterfaceGraphique_1_1Properties_1_1Resources.html", "d7/d9c/classInterfaceGraphique_1_1Properties_1_1Resources" ],
    [ "Settings", "d4/da9/classInterfaceGraphique_1_1Properties_1_1Settings.html", "d4/da9/classInterfaceGraphique_1_1Properties_1_1Settings" ]
];