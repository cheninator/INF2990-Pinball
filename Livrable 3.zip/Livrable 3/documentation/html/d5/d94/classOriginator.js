var classOriginator =
[
    [ "Originator", "d5/d94/classOriginator.html#a8f0760dd0c809ced78a5483f96020220", null ],
    [ "~Originator", "d5/d94/classOriginator.html#a9f9666b89828e8c1010db765975ab583", null ],
    [ "Originator", "d5/d94/classOriginator.html#a4f76b37e11902a9379897b7d5be711ab", null ],
    [ "annuler", "d5/d94/classOriginator.html#a40cbb69704024d2d553d8961b7324757", null ],
    [ "appliquerModifications", "d5/d94/classOriginator.html#abdaa19668d6f8ffb0908abede465e716", null ],
    [ "assignerArbre", "d5/d94/classOriginator.html#a1784777cb0104213a16dfa5282f3ceaa", null ],
    [ "operator=", "d5/d94/classOriginator.html#aa702f415681cde4eeca543a485237103", null ],
    [ "possedePrecedent", "d5/d94/classOriginator.html#aed9f6ff8683da52e71a3ef06d20f1ef3", null ],
    [ "possedeSuivant", "d5/d94/classOriginator.html#a8e081172c404dca5fa18134f34089b58", null ],
    [ "retablir", "d5/d94/classOriginator.html#aa3dfe7db6007d384b728bc15e231def9", null ],
    [ "sauvegarder", "d5/d94/classOriginator.html#a48a6544916e0a7866e8fdd2540c83a94", null ],
    [ "viderHistorique", "d5/d94/classOriginator.html#a3ea2bfdd13553d72b3e31df3d577200d", null ],
    [ "historique_", "d5/d94/classOriginator.html#a581abd19051e103e60ad6fb14e0a476e", null ],
    [ "nullptr", "d5/d94/classOriginator.html#a8338540e08084f699e79c5bfcca71dc3", null ],
    [ "position_", "d5/d94/classOriginator.html#ab9256e5e555677383d7a3052c8f0a599", null ]
];